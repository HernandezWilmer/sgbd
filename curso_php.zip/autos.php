<?php
//ARRAY ASOCIATIVO
$autos = array(
    "Roadster" => array(
        "precio" => 50,
        "puertas" => 4,
        "imagen" => "roadster.jpg"
    ),
    "Model X" => array(
        "precio" => 60,
        "puertas" => 5,
        "imagen" => "modelX.jpg"
    ),
    "Model S" => array(
        "precio" => 70,
        "puertas" => 5,
        "imagen" => "modelS.jpg"
    ),
    "Model 3" => array(
        "precio" => 70,
        "puertas" => 5,
        "imagen" => "model3.jpg"
    ),
    "Model Y" => array(
        "precio" => 70,
        "puertas" => 5,
        "imagen" => "modelY.jpg"
    ),
    "Cyberruck" => array(
        "precio" => 90,
        "puertas" => 6,
        "imagen" => "cybertruck.jpg"
    )
);
